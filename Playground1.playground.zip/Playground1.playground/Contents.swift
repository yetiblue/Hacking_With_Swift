import UIKit

//strings
//var name: String
//name = "Tim Mcgraw"

//preferred to use Inferred Type instead //
var name = "Tim Mcgraw"
var spongeBob = "tIm mCgRaW"
var name2 = "Romeo"
var bothNames = name + " " + "and " + name2

spongeBob != name

//Int
var age: Int
age = 25

//Just default to Double since it is more accurate
var latitude: Double
latitude = 36.166667
var longitude: Float
longitude = -86.783333

//string interpolation allows for Swift expressions in between the parentheses
"Your name is \(name), your age is \(age * 2), and your longitude is \(longitude)"

//swift uses camelCase
var stayOutTooLate: Bool
stayOutTooLate = true

//Arrays
var songs: [String] = ["Shake it off", "You Belong with me", "Love Story"]
var anything: [Any] = ["Shake it off", 3]
var emptyArray = [String]() //creates empty array
songs += ["everything has changed"]

//Dicts
var person = [
    "first": "Taylor",
    "last": "Swift",
    "month": "December"
]
person["first"]
//for-loops
for i in 1...10 {
    print("\(i) x 10 is \(i * 10)")
}
//when enumerated value isnt important
var str = "Fakers gonna"
for _ in 1...5{
    str += " fake"
}
var people = ["players", "haters", "heart-breakers", "fakers"]
var actions = ["play", "hate", "break", "fake"]

for i in 0 ..< people.count {
    print("\(people[i]), gonna \(actions[i])")
}
//while loops
var counter = 0
while true {
    print("counter is now \(counter)")
    counter += 1
    if counter == 200{
        break //keyword for escaping loops
    }
}

for song in songs {
    if song == "You Belong with me" {
        continue //skips this current iteration that matches song name
    }
    print("My favorite song is \(song)")
}

let studioAlbums = 3

switch studioAlbums {
case 0...1:
    print("You're just starting out")
case 2...3:
    print("You're a rising star")
case 3...4:
    print("You're world famous")
default:
    print("Have you done something new?")
}
//functions
func favoriteAlbum(name: String){
    print("My Favorite is \(name)")
}
favoriteAlbum(name: "fearless")

func printAlbumRelease(name: String, year: Int){
    print("\(name) was released in \(year)")
}
printAlbumRelease(name: "fearless", year: 2008)

func countLetters(in string: String){ //define parameter twice. First for external, second for internal
    print("The string \(string) has \(string.count) letters.")
}
countLetters(in: "hello")

//return data type
func albumIsTaylor(name: String) -> Bool {
    if name == "Taylor Swift" { return true }
    if name == "Fearless" { return true }
    if name == "Speak Now" { return true }
    if name == "Red" { return true }
    if name == "1989" { return true }

    return false
}
